from itertools import *


def decod(R, S=9):

    R = str(R)
    LR = len(R)

    M = len(str(123*S))


    # Definizione degli ordine

    qp = range(2, M+1)                      ## Liste larghezza prodotto
    qr = range(1, len(str(S))+1)        ## Liste larghezza random factor

    ## Ogni ordine degli prodotti
    pq = [r for r in product(qp, repeat=int(LR/M))]

    ## Ogni ordine degli rfactors
    pr = [r for r in product(qr, repeat=int(LR/M))]

    ## Ogni ordine ((prodotti), (rfactors))
    p1 = [r for r in product(pq, pr)]
    p2 = []

    ### Sintesi nella forme ((prodotto, rfactor))
    for m in p1:
        tq = m[0]
        tr = m[1]
        tp = []
        for i in range(len(m)):
            tp.append((tq[i], tr[i]))
        tp = tuple(tp)
        p2.append(tp)

    print(p2)
    ### Eliminazione degli tuples ordinai con la longezza diff di R

    ctr = 0
    p = []
    while ctr < len(p2):  
        sm = 0
        for cpl in p2[ctr]:
            for n in cpl:
                sm += n
        if sm == LR:
            p.append(p2[ctr])
        ctr += 1
            
                 
    return p



print(decod(44046306, 9))
