from itertools import *


def decod(R, S):
    

    R = str(R)
    LR = len(R)

    M = len(str(123*S))


    # Definizione degli ordine

    qp = range(2, M+1)                      ## Liste larghezza prodotto
    qr = range(1, len(str(S))+1)        ## Liste larghezza random factor

    ## Ogni ordine degli prodotti
    pq = [r for r in product(qp, repeat=int(LR/M))]

    ## Ogni ordine degli rfactors
    pr = [r for r in product(qr, repeat=int(LR/M))]

    ## Ogni ordine ((prodotti), (rfactors))
    p1 = [r for r in product(pq, pr)]
    p2 = []

    ### Sintesi nella forme ((prodotto, rfactor))
    for m in p1:
        tq = m[0]
        tr = m[1]
        tp = []
        for i in range(len(tq)):
            tp.append((tq[i], tr[i]))
        tp = tuple(tp)
        p2.append(tp)

    ### Eliminazione degli tuples ordinai con la longezza diff di R

    ctr = 0
    p = []
    while ctr < len(p2):  
        sm = 0
        for cpl in p2[ctr]:
            for n in cpl:
                sm += n
        if sm == LR:
            p.append(p2[ctr])
        ctr += 1

    if p == []:                                     #### Return anticipato se p fosse vuoto
        accept = "pv"
        return accept

    
    print("* Ordine creati")            #### Debug
    #print(f"qp={qp}, qr={qr}, pq={1}, pr={2}, p1={p1}, p2={p2}, p={p}")
    
    # Uso degli ordine

    ## Variables
    
    skip = 0
    dr = ""
    rr = ""
    cont = 0

    results = {}      ### Results dict

     ## Giri principale

    ### Va tra tutti i ordini
    while cont < len(p):
        
        ordr = p[cont]
        #print(f"\nTry {cont+1} with {ordr}:", end=" ")                 # Debug
        skip = 0
        tempr = []

        ### Va tra tutti i abbinamenti dell ordino
        for cpl in ordr:

            #### Prima larghezza, prodotto
            dr = ""
            for m in range(cpl[0]):
                dr = dr + str(R[m + skip])

            dr = int(dr)
            skip += cpl[0]

            #### Seconda larghezza, rfactor
            rr = ""
            for m in range(cpl[1]):
                rr = rr + str(R[m + skip])

            rr = int(rr)
            skip += cpl[1]
            
            #### Divisione + verifica dei fattori
            if rr == 0:
                d = -1
            else:
                d = dr / rr
            
            #print(f"(dr={dr}, rr={rr}, d={round(d, 1)})", end=" ")                     # Degug

           ##### Puoi tratto della divisione 
            if d in range(97,123):
                d = int(d)
                #print(chr(d), end=" ")     # Debug
                tempr.append(chr(d))

            elif type(d) == "float" or type(d) == "int":
                tempr.append("/")
                #print("/", end=" ")             # Debug
                break
                
            else:
                tempr.append("#")
                #print("#", end=" ")            # Debug
                break


        results[ordr] = tempr
        cont = cont + 1

    
    ## Resultati finali
    laccept = []
    lsemi = []
    for ordr, word in results.items():
        if (not "/" in word) and (not "#" in word) and (word !=  ""):
            laccept.append(word)
        elif len(word) > 1:
            lsemi.append(word)

    ### Compacting resultati
    accept = []
    if laccept != []:
        for word in laccept:
            tmpacc = ""
            for letter in word:
                tmpacc += letter
            accept.append(tmpacc)
    else:
        accept = "nr"

    
    semi = []
    if lsemi != []:
        for word in lsemi:
            tmpacc = ""
            for letter in word:
                if letter != "/" and letter != "#":
                    tmpacc += letter
            if not tmpacc in semi:
                semi.append(tmpacc)
                
        
            
                
    
    return accept, semi





# Inizzio dell Ui

print("* Lei usa la versione 0.20 dell decoder THe")


R = (input("Entra il codice a decodare (int): "))
try:
    R = int(R)
except ValueError:
    R = False

while R:                             ## Break quando l'user Enter
    print(f"Entrare i valore seguenti, R={R} (Enter to quit)")
    
    S = (input("Entra la larghezza massima dell random (default=9, int): "))
    try:
        S = int(S)
    except ValueError:
        break
    
    
    print(f"* Inizio del programma con S={S} & R={R}")

    accept, semi = decod(R, S)

    print("\n\n* Resultati")
    
    if accept == "pv":
        print(" - Il programma è uscita in anticipo a causa di p stando vuoto")
    elif accept == "nr":
        print(" - Il programma sembra di avere trovato niente. Magari provare di aumentare S.")
        print(f"Risulatati incomplessi: {semi}")
    else:
        print(" - Il programma a trovato:\n{}".format(accept))


    input("\nPress Enter to continue...")
    
# 44046306 ni
