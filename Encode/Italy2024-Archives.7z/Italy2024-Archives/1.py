
from itertools import *


M = 3
L = 2
q = (M+1)**(M+1)        # Quantita' massimale

lc = ""
l = []
p = [2,3,4]

for i in range(M+1):
    l.append(i)
    lc = lc + str(i)



print("Inizio")


"""
#Prima prova per un M solo di 1

for a in l:
    for b in l:
        print(a, b)
"""


#Seconda prova, piu modolare
"""
print([r for r in product(str(lc), repeat=(M+1))])

print([r for r in product(p, repeat=(M+1))])
"""


#Terza proza, con limitazione di soma
