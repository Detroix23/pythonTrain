
"""
Encodeur d'une entrée par des nombres aléatoires,
Idée de Thiago, ou l'output serait une suite de nombre: "nnnnrnnnrnnnnr"

* Algo de codage: val * nb aleatoire - fibo(n)  
* Cracking algo: /decodThe 
"""


from random import *
from itertools import *


def al(style="lil"):
    #Create the alphabet dict L[code] = "letter"
    print("* Creating alphabet")
    
    L = {}
    
    if style == "lil":
        for code in range(97,123):
            val = str(code)
            """
            while len(val) < 4:
                val = "0" + val
            """
            
            #print(val,code,chr(code))          ### Debug
            L[code] = str(chr(code))
    return L

def enc(c, S):
    
    print("* Starting the encoding process")
   
    # Variables
    L = al()    #Alphabet
    fiboa = 1
    fibob = 1
    rt = {}     #Results in a nice dict
    rch = ""    #Results on 1 line
    
    #Enumerate letters
    for lc in c:
        
        r = -1
        
        for code, ll in L.items():
            if lc == " ":
                r = 0
            elif lc == ll:
                
                #Encode
                ## Random value
                ranv = randint(1, S)
                r = code * ranv

                # Fibonacci
                """
                fiboa = fiboa + fibob

                r = r - fiboa
                """
                
                rt[r] = ranv
                print(code,ranv,fiboa,r)       ### Debug
        if r == -1:
            #If not in alphabet
            rt[lc] = ""
            
            print(lc)                                           ### Debug
    
    #Loop dict to set all the chars on one line 

    
    for a, b in rt.items():
        rch = rch + str(a) + str(b)
        
    return rch
            

while True:             ## Break out of the loop if user inputs "q"
    #Ask user
    print("============THeCode============")
    print("\n* Start encoder")
    c = input("Type text to encode: ")
    c = c.lower()
    
    S = input("Size of randomness (int): ")
    S = int(S)
    
    rch = enc(c, S)
    print(rch)

    ## Quit  ?
    qu = input("\n'q' to quit or press Enter to go anew...")
    if qu != "" or qu =="q" or qu == "Q":
        break
    else:
        print("\n")
        
    

