
# Character Card generator

**charCard** is an python program that is used to generate, from an user input, a RPG character card in HTML and styled in CSS

By Detroix23

The 05/12/2024

# Package

The **charCard** folder should contain the following:

- html (folder)
	- model.html
- charCard.py
- info.md (this file)
- style.css

# Usage

1. Run the python file (you must have Python installed from https://www.python.org/)
2. In the console, enter first the title, then parameters and values that you like. Enter 'n' when you have enough.
3. If everything worked fine, a 'Succes' prompt will show up and the newly created HTML page will be located in the html folder.


# License

The entierty of the this material under the license **Do the Fuck you want** wich means that you can use it at will, in non-profit and profit uses, modify it. 

However, you still need to mention the original creator, Detroix23 when you use it for profit and/ or modyfing it.

Furthermore, by accepting this license, you also accept that you use this material at your own riskes and that the original creator, Detroix23, is not related to any misunderstandings, failures or injuries whatsoever.